// Caricamento dei dati e inizializzazione
document.addEventListener('DOMContentLoaded', function() {
    // Carica i dati JSON
    fetch('royalties_data.json')
        .then(response => response.json())
        .then(data => {
            // Inizializza la visualizzazione con i dati
            initializeStatistics(data);
            initializeTable(data);
            initializeCharts(data);
            setupEventListeners(data);
        })
        .catch(error => console.error('Errore nel caricamento dei dati:', error));
});

// Funzione per inizializzare le statistiche
function initializeStatistics(data) {
    // Calcola le statistiche
    const valori = data.map(item => item.valore);
    const totale = valori.reduce((acc, val) => acc + val, 0);
    const media = totale / valori.length;
    const massimo = Math.max(...valori);
    const minimo = Math.min(...valori.filter(val => val > 0)); // Considera solo valori positivi per il minimo
    
    // Aggiorna gli elementi HTML
    document.getElementById('totale').textContent = formatCurrency(totale);
    document.getElementById('media').textContent = formatCurrency(media);
    document.getElementById('massimo').textContent = formatCurrency(massimo);
    document.getElementById('minimo').textContent = formatCurrency(minimo);
}

// Funzione per inizializzare la tabella
function initializeTable(data) {
    const tableBody = document.querySelector('#royaltiesTable tbody');
    
    // Svuota la tabella
    tableBody.innerHTML = '';
    
    // Popola la tabella con i dati
    data.forEach(item => {
        const row = document.createElement('tr');
        
        const descCell = document.createElement('td');
        descCell.textContent = item.descrizione;
        
        const valueCell = document.createElement('td');
        valueCell.textContent = formatCurrency(item.valore);
        valueCell.classList.add('text-end'); // Allinea a destra i valori numerici
        
        row.appendChild(descCell);
        row.appendChild(valueCell);
        tableBody.appendChild(row);
    });
    
    // Inizializza DataTables per funzionalità interattive
    $(document).ready(function() {
        $('#royaltiesTable').DataTable({
            language: {
                url: '//cdn.datatables.net/plug-ins/1.13.6/i18n/it-IT.json'
            },
            responsive: true,
            order: [[1, 'desc']], // Ordina per valore (seconda colonna) in ordine decrescente
            columnDefs: [
                { targets: 1, type: 'num-fmt' } // Specifica che la seconda colonna contiene numeri formattati
            ]
        });
    });
}

// Funzione per inizializzare i grafici
function initializeCharts(data) {
    // Prepara i dati per i grafici
    const labels = data.map(item => item.descrizione);
    const values = data.map(item => item.valore);
    
    // Filtra i dati per i codici specifici (ATD, ALX, EB, AMZ)
    const codiciData = data.filter(item => 
        item.descrizione.includes('Codice ATD') || 
        item.descrizione.includes('Codice ALX') || 
        item.descrizione.includes('Codice EB') || 
        item.descrizione.includes('Codice AMZ')
    );
    
    const codiciLabels = codiciData.map(item => {
        // Estrae il nome del codice dalla descrizione
        const match = item.descrizione.match(/Codice\s+(\w+)/);
        return match ? match[1] : item.descrizione;
    });
    
    const codiciValues = codiciData.map(item => item.valore);
    
    // Colori per i grafici
    const backgroundColors = [
        'rgba(26, 115, 232, 0.7)',
        'rgba(52, 168, 83, 0.7)',
        'rgba(251, 188, 5, 0.7)',
        'rgba(234, 67, 53, 0.7)',
        'rgba(103, 58, 183, 0.7)',
        'rgba(0, 188, 212, 0.7)',
        'rgba(255, 152, 0, 0.7)',
        'rgba(139, 195, 74, 0.7)'
    ];
    
    // Grafico a torta per la distribuzione del fatturato
    const pieCtx = document.getElementById('pieChart').getContext('2d');
    const pieChart = new Chart(pieCtx, {
        type: 'pie',
        data: {
            labels: codiciLabels,
            datasets: [{
                data: codiciValues,
                backgroundColor: backgroundColors,
                borderColor: 'white',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'right',
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const value = context.raw;
                            const total = context.dataset.data.reduce((acc, val) => acc + val, 0);
                            const percentage = ((value / total) * 100).toFixed(1);
                            return `${context.label}: ${formatCurrency(value)} (${percentage}%)`;
                        }
                    }
                }
            }
        }
    });
    
    // Grafico a barre per il confronto del fatturato per codice
    const barCtx = document.getElementById('barChart').getContext('2d');
    const barChart = new Chart(barCtx, {
        type: 'bar',
        data: {
            labels: codiciLabels,
            datasets: [{
                label: 'Fatturato per Codice',
                data: codiciValues,
                backgroundColor: backgroundColors,
                borderColor: backgroundColors.map(color => color.replace('0.7', '1')),
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return '€' + value.toLocaleString('it-IT');
                        }
                    }
                }
            },
            plugins: {
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return `Fatturato: ${formatCurrency(context.raw)}`;
                        }
                    }
                }
            }
        }
    });
    
    // Grafico dettagliato (inizialmente a barre)
    const detailedCtx = document.getElementById('detailedChart').getContext('2d');
    window.detailedChart = new Chart(detailedCtx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: 'Fatturato',
                data: values,
                backgroundColor: backgroundColors,
                borderColor: backgroundColors.map(color => color.replace('0.7', '1')),
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return '€' + value.toLocaleString('it-IT');
                        }
                    }
                }
            },
            plugins: {
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return `Fatturato: ${formatCurrency(context.raw)}`;
                        }
                    }
                }
            }
        }
    });
}

// Funzione per impostare i listener degli eventi
function setupEventListeners(data) {
    // Toggle tra visualizzazione a barre e a torta per il grafico dettagliato
    document.getElementById('viewBar').addEventListener('click', function() {
        this.classList.add('active');
        document.getElementById('viewPie').classList.remove('active');
        updateChartType('bar', data);
    });
    
    document.getElementById('viewPie').addEventListener('click', function() {
        this.classList.add('active');
        document.getElementById('viewBar').classList.remove('active');
        updateChartType('pie', data);
    });
}

// Funzione per aggiornare il tipo di grafico
function updateChartType(type, data) {
    const labels = data.map(item => item.descrizione);
    const values = data.map(item => item.valore);
    
    // Distruggi il grafico esistente
    window.detailedChart.destroy();
    
    // Crea un nuovo grafico con il tipo specificato
    const detailedCtx = document.getElementById('detailedChart').getContext('2d');
    
    const backgroundColors = [
        'rgba(26, 115, 232, 0.7)',
        'rgba(52, 168, 83, 0.7)',
        'rgba(251, 188, 5, 0.7)',
        'rgba(234, 67, 53, 0.7)',
        'rgba(103, 58, 183, 0.7)',
        'rgba(0, 188, 212, 0.7)',
        'rgba(255, 152, 0, 0.7)',
        'rgba(139, 195, 74, 0.7)'
    ];
    
    const options = {
        responsive: true,
        plugins: {
            tooltip: {
                callbacks: {
                    label: function(context) {
                        return `Fatturato: ${formatCurrency(context.raw)}`;
                    }
                }
            }
        }
    };
    
    // Aggiungi opzioni specifiche per il tipo di grafico
    if (type === 'bar') {
        options.scales = {
            y: {
                beginAtZero: true,
                ticks: {
                    callback: function(value) {
                        return '€' + value.toLocaleString('it-IT');
                    }
                }
            }
        };
    } else if (type === 'pie') {
        options.plugins.legend = {
            position: 'right'
        };
        options.plugins.tooltip.callbacks.label = function(context) {
            const value = context.raw;
            const total = context.dataset.data.reduce((acc, val) => acc + val, 0);
            const percentage = ((value / total) * 100).toFixed(1);
            return `${context.label}: ${formatCurrency(value)} (${percentage}%)`;
        };
    }
    
    window.detailedChart = new Chart(detailedCtx, {
        type: type,
        data: {
            labels: labels,
            datasets: [{
                label: 'Fatturato',
                data: values,
                backgroundColor: backgroundColors,
                borderColor: backgroundColors.map(color => color.replace('0.7', '1')),
                borderWidth: 1
            }]
        },
        options: options
    });
}

// Funzione per formattare i valori monetari
function formatCurrency(value) {
    return '€' + value.toLocaleString('it-IT', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    });
}
