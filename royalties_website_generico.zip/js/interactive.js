// Funzionalità di ricerca avanzata
function setupSearchFunctionality() {
    // Aggiungi campo di ricerca sopra la tabella
    const tableContainer = document.querySelector('#tabella .card-body');
    const searchDiv = document.createElement('div');
    searchDiv.className = 'mb-4';
    searchDiv.innerHTML = `
        <div class="row">
            <div class="col-md-6 mb-3 mb-md-0">
                <div class="input-group">
                    <span class="input-group-text"><i class="fas fa-search"></i></span>
                    <input type="text" id="searchInput" class="form-control" placeholder="Cerca per descrizione...">
                </div>
            </div>
            <div class="col-md-6">
                <div class="input-group">
                    <span class="input-group-text">Valore minimo</span>
                    <input type="number" id="minValueFilter" class="form-control" placeholder="€">
                    <span class="input-group-text">Valore massimo</span>
                    <input type="number" id="maxValueFilter" class="form-control" placeholder="€">
                </div>
            </div>
        </div>
    `;
    
    // Inserisci il campo di ricerca prima della tabella
    tableContainer.insertBefore(searchDiv, tableContainer.firstChild);
    
    // Aggiungi funzionalità di ricerca
    document.getElementById('searchInput').addEventListener('keyup', applyFilters);
    document.getElementById('minValueFilter').addEventListener('change', applyFilters);
    document.getElementById('maxValueFilter').addEventListener('change', applyFilters);
}

// Funzione per applicare i filtri
function applyFilters() {
    const searchTerm = document.getElementById('searchInput').value.toLowerCase();
    const minValue = parseFloat(document.getElementById('minValueFilter').value) || 0;
    const maxValue = parseFloat(document.getElementById('maxValueFilter').value) || Infinity;
    
    const table = $('#royaltiesTable').DataTable();
    
    // Applica filtro personalizzato
    $.fn.dataTable.ext.search.push(
        function(settings, data, dataIndex) {
            const description = data[0].toLowerCase();
            const value = parseFloat(data[1].replace(/[€.]/g, '').replace(',', '.')) || 0;
            
            // Verifica se la descrizione contiene il termine di ricerca
            const matchesSearch = description.includes(searchTerm);
            
            // Verifica se il valore è nell'intervallo specificato
            const matchesRange = value >= minValue && value <= maxValue;
            
            return matchesSearch && matchesRange;
        }
    );
    
    // Ridisegna la tabella con i filtri applicati
    table.draw();
    
    // Rimuovi il filtro personalizzato dopo l'applicazione
    $.fn.dataTable.ext.search.pop();
}

// Funzione per aggiungere funzionalità di esportazione
function addExportFunctionality() {
    const exportDiv = document.createElement('div');
    exportDiv.className = 'mb-3 text-end';
    exportDiv.innerHTML = `
        <div class="btn-group">
            <button id="exportCSV" class="btn btn-outline-primary">
                <i class="fas fa-file-csv"></i> Esporta CSV
            </button>
            <button id="exportPDF" class="btn btn-outline-primary">
                <i class="fas fa-file-pdf"></i> Esporta PDF
            </button>
            <button id="printData" class="btn btn-outline-primary">
                <i class="fas fa-print"></i> Stampa
            </button>
        </div>
    `;
    
    // Inserisci i pulsanti di esportazione sopra la tabella
    const tableSection = document.querySelector('#tabella .container');
    tableSection.insertBefore(exportDiv, tableSection.querySelector('h2').nextSibling);
    
    // Aggiungi event listener per l'esportazione CSV
    document.getElementById('exportCSV').addEventListener('click', function() {
        exportToCSV();
    });
    
    // Aggiungi event listener per l'esportazione PDF
    document.getElementById('exportPDF').addEventListener('click', function() {
        exportToPDF();
    });
    
    // Aggiungi event listener per la stampa
    document.getElementById('printData').addEventListener('click', function() {
        window.print();
    });
}

// Funzione per esportare i dati in CSV
function exportToCSV() {
    fetch('royalties_data.json')
        .then(response => response.json())
        .then(data => {
            let csvContent = "Descrizione,Valore\n";
            
            data.forEach(item => {
                csvContent += `"${item.descrizione}",${item.valore}\n`;
            });
            
            // Crea un blob e un link per il download
            const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
            const url = URL.createObjectURL(blob);
            const link = document.createElement('a');
            link.setAttribute('href', url);
            link.setAttribute('download', 'royalties_marzo_2025.csv');
            link.style.visibility = 'hidden';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        })
        .catch(error => console.error('Errore nell\'esportazione CSV:', error));
}

// Funzione per esportare i dati in PDF
function exportToPDF() {
    // Questa è una simulazione di esportazione PDF
    // In un'implementazione reale, si utilizzerebbe una libreria come jsPDF
    alert('Funzionalità di esportazione PDF in fase di implementazione. Utilizzare l\'esportazione CSV o la funzione di stampa.');
}

// Funzione per aggiungere confronto anno precedente
function addYearComparisonToggle() {
    // Aggiungi toggle per confronto con anno precedente
    const comparisonDiv = document.createElement('div');
    comparisonDiv.className = 'form-check form-switch mb-3';
    comparisonDiv.innerHTML = `
        <input class="form-check-input" type="checkbox" id="yearComparisonToggle">
        <label class="form-check-label" for="yearComparisonToggle">
            Mostra confronto con anno precedente (simulato)
        </label>
    `;
    
    // Inserisci il toggle sopra i grafici
    const graphSection = document.querySelector('#grafici .container');
    graphSection.insertBefore(comparisonDiv, graphSection.querySelector('h2').nextSibling);
    
    // Aggiungi event listener per il toggle
    document.getElementById('yearComparisonToggle').addEventListener('change', function() {
        toggleYearComparison(this.checked);
    });
}

// Funzione per mostrare/nascondere il confronto con l'anno precedente
function toggleYearComparison(show) {
    if (show) {
        // Simula dati dell'anno precedente (80-90% dei valori attuali)
        fetch('royalties_data.json')
            .then(response => response.json())
            .then(data => {
                const currentData = data.map(item => item.valore);
                const previousYearData = currentData.map(value => value * (0.8 + Math.random() * 0.1)); // 80-90% dei valori attuali
                
                // Aggiorna il grafico a barre per mostrare il confronto
                updateBarChartWithComparison(data.map(item => item.descrizione), currentData, previousYearData);
            })
            .catch(error => console.error('Errore nel caricamento dei dati per confronto:', error));
    } else {
        // Ripristina il grafico originale
        fetch('royalties_data.json')
            .then(response => response.json())
            .then(data => {
                initializeCharts(data);
            })
            .catch(error => console.error('Errore nel ripristino dei grafici:', error));
    }
}

// Funzione per aggiornare il grafico a barre con il confronto
function updateBarChartWithComparison(labels, currentData, previousYearData) {
    // Distruggi il grafico esistente
    if (window.detailedChart) {
        window.detailedChart.destroy();
    }
    
    // Crea un nuovo grafico con i dati di confronto
    const detailedCtx = document.getElementById('detailedChart').getContext('2d');
    window.detailedChart = new Chart(detailedCtx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [
                {
                    label: 'Marzo 2025',
                    data: currentData,
                    backgroundColor: 'rgba(26, 115, 232, 0.7)',
                    borderColor: 'rgba(26, 115, 232, 1)',
                    borderWidth: 1
                },
                {
                    label: 'Marzo 2024 (simulato)',
                    data: previousYearData,
                    backgroundColor: 'rgba(234, 67, 53, 0.7)',
                    borderColor: 'rgba(234, 67, 53, 1)',
                    borderWidth: 1
                }
            ]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return '€' + value.toLocaleString('it-IT');
                        }
                    }
                }
            },
            plugins: {
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return `${context.dataset.label}: ${formatCurrency(context.raw)}`;
                        }
                    }
                }
            }
        }
    });
}

// Aggiungi queste funzioni all'inizializzazione
document.addEventListener('DOMContentLoaded', function() {
    // Carica Font Awesome per le icone
    const fontAwesome = document.createElement('link');
    fontAwesome.rel = 'stylesheet';
    fontAwesome.href = 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css';
    document.head.appendChild(fontAwesome);
    
    // Carica i dati JSON
    fetch('royalties_data.json')
        .then(response => response.json())
        .then(data => {
            // Inizializza la visualizzazione con i dati
            initializeStatistics(data);
            initializeTable(data);
            initializeCharts(data);
            setupEventListeners(data);
            
            // Aggiungi funzionalità interattive avanzate
            setupSearchFunctionality();
            addExportFunctionality();
            addYearComparisonToggle();
        })
        .catch(error => console.error('Errore nel caricamento dei dati:', error));
});
