// Funzionalità per gestire la selezione del mese e dell'anno
document.addEventListener('DOMContentLoaded', function() {
    // Imposta la data di ultimo aggiornamento
    updateLastUpdateDate();
    
    // Aggiungi event listener per i selettori di mese e anno
    document.getElementById('monthSelector').addEventListener('change', updatePeriod);
    document.getElementById('yearSelector').addEventListener('change', updatePeriod);
    
    // Inizializza con il periodo corrente
    updatePeriod();
});

// Funzione per aggiornare il periodo selezionato
function updatePeriod() {
    const monthSelector = document.getElementById('monthSelector');
    const yearSelector = document.getElementById('yearSelector');
    
    const selectedMonth = monthSelector.options[monthSelector.selectedIndex].text;
    const selectedYear = yearSelector.value;
    
    // Aggiorna il titolo della pagina
    document.title = `Dashboard Royalties - ${selectedMonth} ${selectedYear}`;
    
    // Aggiorna i titoli delle sezioni
    updateSectionTitles(selectedMonth, selectedYear);
    
    // Qui in un'implementazione reale si caricherebbero i dati del periodo selezionato
    // Per questa demo, utilizziamo i dati esistenti ma aggiorniamo le etichette
    updateDataLabels(selectedMonth, selectedYear);
}

// Funzione per aggiornare i titoli delle sezioni
function updateSectionTitles(month, year) {
    // Aggiorna i titoli delle sezioni con il periodo selezionato
    document.querySelectorAll('.period-label').forEach(element => {
        element.textContent = `${month} ${year}`;
    });
}

// Funzione per aggiornare le etichette dei dati
function updateDataLabels(month, year) {
    // In un'implementazione reale, qui si aggiornerebbero i dati in base al periodo selezionato
    // Per questa demo, aggiorniamo solo le etichette dei grafici
    
    if (window.pieChart) {
        window.pieChart.options.plugins.title.text = `Distribuzione Fatturato - ${month} ${year}`;
        window.pieChart.update();
    }
    
    if (window.barChart) {
        window.barChart.options.plugins.title.text = `Confronto Fatturato per Codice - ${month} ${year}`;
        window.barChart.update();
    }
    
    if (window.detailedChart) {
        window.detailedChart.options.plugins.title.text = `Analisi Dettagliata - ${month} ${year}`;
        window.detailedChart.update();
    }
}

// Funzione per aggiornare la data di ultimo aggiornamento
function updateLastUpdateDate() {
    const now = new Date();
    const options = { year: 'numeric', month: 'long', day: 'numeric' };
    document.getElementById('lastUpdate').textContent = now.toLocaleDateString('it-IT', options);
}

// Estendi la funzione di inizializzazione dei grafici per supportare i titoli
function extendChartInitialization() {
    // Aggiungi titoli ai grafici esistenti
    if (window.pieChart) {
        window.pieChart.options.plugins.title = {
            display: true,
            text: 'Distribuzione Fatturato',
            font: {
                size: 16
            }
        };
        window.pieChart.update();
    }
    
    if (window.barChart) {
        window.barChart.options.plugins.title = {
            display: true,
            text: 'Confronto Fatturato per Codice',
            font: {
                size: 16
            }
        };
        window.barChart.update();
    }
    
    if (window.detailedChart) {
        window.detailedChart.options.plugins.title = {
            display: true,
            text: 'Analisi Dettagliata',
            font: {
                size: 16
            }
        };
        window.detailedChart.update();
    }
}

// Aggiungi questa funzione all'inizializzazione
document.addEventListener('DOMContentLoaded', function() {
    // Carica i dati JSON
    fetch('royalties_data.json')
        .then(response => response.json())
        .then(data => {
            // Inizializza la visualizzazione con i dati
            initializeStatistics(data);
            initializeTable(data);
            initializeCharts(data);
            setupEventListeners(data);
            
            // Aggiungi funzionalità interattive avanzate
            setupSearchFunctionality();
            addExportFunctionality();
            addYearComparisonToggle();
            
            // Estendi l'inizializzazione dei grafici
            extendChartInitialization();
            
            // Aggiorna il periodo selezionato
            updatePeriod();
        })
        .catch(error => console.error('Errore nel caricamento dei dati:', error));
});
